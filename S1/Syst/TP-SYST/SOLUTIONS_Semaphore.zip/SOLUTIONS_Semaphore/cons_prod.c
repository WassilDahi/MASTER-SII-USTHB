#include <sys/types.h> 
#include <sys/ipc.h> 
#include <sys/sem.h> 
#include <unistd.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <ctype.h> 
#include<pthread.h>
#include<sys/wait.h>
#include<sys/types.h>

#define BUFSIZE 10
#define MUTEX 0
#define FULL 1
#define EMPTY 2

int buffer[BUFSIZE];
int in = 0;
int out = 0;

int i = 10000;
int j = 10000;
union semun{  
            int val;
            struct semid_ds *buf;
            ushort *array;
            } arg;
int semid; 
          
void detruire_sem(int sem) { // supprime le groupe de semaphore
              if (semctl(sem, 0, IPC_RMID, 0) != 0) { 
                      perror("detruire_sem"); 
                      exit(EXIT_FAILURE); 
              }; 
      } 

int semcreate(key_t key, int n){ 
              int sem; 
             
              sem = semget(key, n, IPC_CREAT| IPC_EXCL|0666); 
             if (sem < 0) { 
                      perror("creer_sem"); 
                      exit(EXIT_FAILURE); 
              };
              
               return sem; 
        }
              
int seminit (int idsem, int numsem, union semun initval){ 
              int r; 
             if(numsem==-1)
             {    
             
                          
             r = semctl(idsem, numsem, SETALL, initval);  /*initialiser toute les sem du groupe a initval */ 
              printf("setALL");
             
             }  
             else {   
                r = semctl(idsem, numsem, SETVAL, initval);  /* valeur initiale = val */ 
                 printf("init Num sem= %d, val = %d\n",numsem, initval.val);
             
             }          
             if (r < 0) { 
                      perror("initialisation sémaphore"); 
                      exit(EXIT_FAILURE); 
              }; 
            
              return idsem; 
               } 
void P(int sem, int numsem)
      {
            struct sembuf buf;
	        buf.sem_num = numsem;
	        buf.sem_op = -1;
	        buf.sem_flg = 0;
	        if(semop(sem, &buf, 1) < 0) {
		        perror("semop:");
		        exit(2);
                      }; 
      } 
void Z(int sem,int numsem) 
      { 
             struct sembuf buf;
	        buf.sem_num = numsem;
	        buf.sem_op = 0;
	        buf.sem_flg = 0;
	        if(semop(sem, &buf, 1) < 0) {
		        perror("semop:");
		        exit(2);
                      };
      } 
 
void V(int sem, int numsem) 
    {             
        struct sembuf buf;
	    buf.sem_num = numsem;
	    buf.sem_op = 1;
	    buf.sem_flg = 0;
	    if(semop(sem, &buf, 1) < 0)
	    {
		    perror("semop:");
		    exit(2);
	    }
     }
     
     
void *thread_producteur(void * var) { //le code a executer par un thread producteur
      
     int ip =0 ;
     ushort  semvalsreturn[3];

    while (i--){ 
       P(semid,EMPTY);
       P(semid,MUTEX);
        /** Critical Section 	**/	
       int m=rand()%100;
       buffer[ip]=m;
       printf("P:   %d      buf[%d] \n",m,ip);
       ip=(ip+1 )% BUFSIZE; ;
        /** 	**/	
       V(semid,MUTEX); ;
       V(semid,FULL) ;
       
       //décommenter pour visualiser les états des sémaphore au cours de l'exécution 
         /*   arg.array = semvalsreturn;
            int retrn = semctl(semid, 0, GETALL, arg);
            for (int i = 0; i < 3; i++)   printf("P: semnum =%d   semval=%d\n",i, semvalsreturn[i]);*/
       }
     pthread_exit((void*)(unsigned long long) 1);
    }
   
void *thread_consomateur(void * var) { //le code a executer par un thread consomateur
     int ic =0 ;
     ushort  semvalsreturn[3];
      while (j--)      
        {
            P(semid,FULL) ;
            P(semid,MUTEX);
            /** Critical Section 	**/	
            int m = buffer[ic];
            
            printf("C:  %d      buf[%d] \n", m,ic);
            ic=(ic+1)% BUFSIZE; ;
            /** 			**/
           
            V(semid,MUTEX);
            V(semid,EMPTY);
            
            //décommenter pour visualiser les états des sémaphore au cours de l'exécution 
           /* arg.array = semvalsreturn;
            int retrn = semctl(semid, 0, GETALL, arg);
            for (int i = 0; i < 3; i++)   printf("C: semnum =%d   semval=%d\n",i, semvalsreturn[i]);*/
            
            
        }
        
     pthread_exit((void*)(unsigned long long) 1);// cast to long unsigned to remove the warning 
    
    }


 void main(){
 
 //creation du segment a faire dans un seul processus puis passer l'identifiant aux autres
   int n;
   key_t key;
   pthread_t tid[4];
   int res[4];
   
   
  
   // creationet initialisation de semaphore
   key=ftok("/usr/games",'v'); //modifier le chemin
   semid=semcreate(key,3);
   arg.val=1;
   
   seminit (semid, MUTEX, arg);
   arg.val=0;
   seminit (semid, FULL, arg);
   arg.val=BUFSIZE;
   seminit (semid, EMPTY, arg);
   
   //creation de thread 
   int a=1;
   pthread_create(&tid[0], NULL,(void*)thread_producteur,(void*)&a);
   pthread_create(&tid[1], NULL,(void*)thread_consomateur,(void*)&a);
  
  
   
   printf("thread principal attend la din des producteurs consomateurs\n");
  
   pthread_join(tid[0], (void **)&res[0]); 
   
   pthread_join(tid[1], (void **)&res[1]); 
   
   
           
    printf("suppression des semaphore\n");
    detruire_sem(semid);
    
        
    
  }
