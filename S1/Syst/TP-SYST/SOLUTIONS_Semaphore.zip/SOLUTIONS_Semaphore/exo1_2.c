/* sem.c */ 
      /*  
         Opérations sur des sémaphores  
      */ 
      #include <sys/types.h> 
      #include <sys/ipc.h> 
      #include <sys/sem.h> 
      #include <unistd.h> 
      #include <stdio.h> 
      #include <stdlib.h> 
      #include <ctype.h> 
      #include    <stdio.h>
 

      typedef int SEMAPHORE; 
      union semun{  
            int val;
            struct semid_ds *buf;
            ushort *array;
            } arg,argn;
            
      void detruire_sem(SEMAPHORE sem) 
      { 
              if (semctl(sem, 0, IPC_RMID, 0) != 0) { 
                      perror("detruire_sem"); 
                      exit(EXIT_FAILURE); 
              }; 
      } 
      void changer_sem(SEMAPHORE sem, int val) 
      { 
              struct sembuf sb[1]; 
              sb[0].sem_num = 0; 
              sb[0].sem_op = val; 
              sb[0].sem_flg = 0; 
              if (semop(sem, sb, 1) != 0) { 
                      perror("changer_sem"); 
               exit(EXIT_FAILURE); 
              }; 
      } 
      SEMAPHORE semcreate(key_t key, int n) 
      { 
              SEMAPHORE sem; 
             
              sem = semget(key, n, IPC_CREAT| IPC_EXCL|0666); 
             if (sem < 0) { 
                      perror("creer_sem"); 
                      exit(EXIT_FAILURE); 
              };
              
               return sem; 
               }
              
       SEMAPHORE seminit (int idsem, int numsem, union semun initval)
       { 
              int r; 
             if(numsem==1)
             {    
             
                          
             r = semctl(idsem, numsem, SETALL, initval);  /*initialiser toute les sem du groupe a initval */ 
              printf("setALL");
             
             }  
             else {   
                r = semctl(idsem, numsem, SETVAL, initval);  /* valeur initiale = val */ 
                 printf("setVAL");
             
             }          
             if (r < 0) { 
                      perror("initialisation sémaphore"); 
                      exit(EXIT_FAILURE); 
              }; 
            
              return idsem; 
      } 
      void P(SEMAPHORE sem) 
      { 
              changer_sem(sem, -1); 
      } 
      void Z(SEMAPHORE sem) 
      { 
              changer_sem(sem, 0); 
      } 
 
      void V(SEMAPHORE sem) 
    {               changer_sem(sem, 1); 
     }
 void main(){
 
 //creation du segment a faire dans un seul processus puis passer l'identifiant aux autres
   int n=4;
   key_t key[n],keyn;
   struct semid_ds semid_ds;
   ushort semvals[n],c, semvalsreturn[n];
   arg.val= 1;
   
   SEMAPHORE sem[n],semn;
   // USING SETVAL
 
   for (int i=0;i<n;i++){
       key[i]=ftok("/usr/games",i); //modifier le chemin
       sem[i]=semcreate(key[i],1);
       seminit (sem[i], 0, arg);
       printf("Sem[%d]  semid= %d\n",i,sem[i]);
       }
       
    //USING SETALL
    /*Set the semaphore set values.*/
 
  printf("\nEnter each value:\n");
  for(int i = 0; i < n; i++) {
      scanf("%hd", &c);
      semvals[i] = c;
      }
     /*Do the system call.*/
  argn.array = semvals;
  keyn=ftok("/usr/games",'c'); //modifier le chemin
  semn=semcreate(keyn,n);
  seminit (semn, 1, argn);
       
      
  //GETALL 
  arg.array = semvalsreturn;
   printf("les valeur des semaphore du groupe semid=%d\n",semn);
  
  int retrn = semctl(semn, 0, GETALL, arg);
  for (int i = 0; i < n; i++){ 
            printf("%d\n", semvalsreturn[i]);
            }     
      
 
          
        printf("suppression des semaphore\n");
        for (int i=0;i<n;i++){
        printf("Sem[%d]  semid= %d\n",i,sem[i]);
        detruire_sem(sem[i]);
        }
        detruire_sem(semn);
        
    
 
 
 
 
 
 
 
 
 }
